// ===== MAIN JAVASCRIPT FILE FOR KHULISOREADS =====

// Global variables and state management
const KhulisoReads = {
    // Application state
    state: {
        currentTheme: 'light',
        currentUser: null,
        books: [],
        readingSessions: [],
        goals: {
            yearly: 20,
            monthly: 2,
            daily: 30,
            streak: 7
        },
        preferences: {
            theme: 'auto',
            defaultView: 'grid',
            notifications: {
                reading: true,
                goals: true,
                achievements: true
            },
            privacy: {
                analytics: true,
                backup: true
            }
        }
    },

    // Initialize the application
    init() {
        this.loadFromStorage();
        this.setupEventListeners();
        this.initializeTheme();
        this.hideLoadingScreen();
        this.loadSampleData();
        this.updateStats();
        this.checkAchievements();
    },

    // Load data from localStorage
    loadFromStorage() {
        const savedState = localStorage.getItem('khulisoReadsState');
        if (savedState) {
            try {
                const parsedState = JSON.parse(savedState);
                this.state = { ...this.state, ...parsedState };
            } catch (error) {
                console.error('Error loading saved state:', error);
            }
        }
    },

    // Save data to localStorage
    saveToStorage() {
        try {
            localStorage.setItem('khulisoReadsState', JSON.stringify(this.state));
        } catch (error) {
            console.error('Error saving state:', error);
        }
    },

    // Setup event listeners
    setupEventListeners() {
        // Navigation
        this.setupNavigation();
        
        // Theme toggle
        this.setupThemeToggle();
        
        // Window events
        window.addEventListener('beforeunload', () => {
            this.saveToStorage();
        });

        // Page-specific event listeners
        this.setupPageSpecificEvents();
    },

    // Setup navigation functionality
    setupNavigation() {
        const hamburger = document.getElementById('hamburger');
        const navMenu = document.getElementById('nav-menu');

        if (hamburger && navMenu) {
            hamburger.addEventListener('click', () => {
                hamburger.classList.toggle('active');
                navMenu.classList.toggle('active');
            });

            // Close menu when clicking on a link
            navMenu.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-link')) {
                    hamburger.classList.remove('active');
                    navMenu.classList.remove('active');
                }
            });

            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!hamburger.contains(e.target) && !navMenu.contains(e.target)) {
                    hamburger.classList.remove('active');
                    navMenu.classList.remove('active');
                }
            });
        }

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    },

    // Setup theme toggle functionality
    setupThemeToggle() {
        const themeToggle = document.getElementById('theme-toggle');
        const themeIcon = themeToggle?.querySelector('.theme-icon');

        if (themeToggle) {
            themeToggle.addEventListener('click', () => {
                this.toggleTheme();
            });
        }
    },

    // Initialize theme based on user preference
    initializeTheme() {
        const savedTheme = this.state.preferences.theme;
        let theme = 'light';

        if (savedTheme === 'auto') {
            theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        } else {
            theme = savedTheme;
        }

        this.setTheme(theme);

        // Listen for system theme changes
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (this.state.preferences.theme === 'auto') {
                this.setTheme(e.matches ? 'dark' : 'light');
            }
        });
    },

    // Set theme
    setTheme(theme) {
        this.state.currentTheme = theme;
        document.documentElement.setAttribute('data-theme', theme);
        
        const themeIcon = document.querySelector('.theme-icon');
        if (themeIcon) {
            themeIcon.textContent = theme === 'dark' ? '☀️' : '🌙';
        }

        this.saveToStorage();
    },

    // Toggle theme
    toggleTheme() {
        const newTheme = this.state.currentTheme === 'light' ? 'dark' : 'light';
        this.state.preferences.theme = newTheme;
        this.setTheme(newTheme);
        this.showNotification('Theme changed to ' + newTheme + ' mode', 'success');
    },

    // Hide loading screen
    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            setTimeout(() => {
                loadingScreen.classList.add('hidden');
                setTimeout(() => {
                    loadingScreen.style.display = 'none';
                }, 500);
            }, 1500);
        }
    },

    // Load sample data for demonstration
    loadSampleData() {
        if (this.state.books.length === 0) {
            this.state.books = [
                {
                    id: 1,
                    title: "The Great Gatsby",
                    author: "F. Scott Fitzgerald",
                    genre: "fiction",
                    pages: 180,
                    currentPage: 180,
                    status: "completed",
                    dateAdded: new Date('2024-01-15'),
                    dateCompleted: new Date('2024-02-01'),
                    rating: 5,
                    description: "A classic American novel set in the Jazz Age, exploring themes of wealth, love, and the American Dream."
                },
                {
                    id: 2,
                    title: "Dune",
                    author: "Frank Herbert",
                    genre: "sci-fi",
                    pages: 688,
                    currentPage: 245,
                    status: "currently-reading",
                    dateAdded: new Date('2024-02-10'),
                    rating: 0,
                    description: "A science fiction epic set on the desert planet Arrakis, following Paul Atreides and his journey."
                },
                {
                    id: 3,
                    title: "Atomic Habits",
                    author: "James Clear",
                    genre: "non-fiction",
                    pages: 320,
                    currentPage: 0,
                    status: "want-to-read",
                    dateAdded: new Date('2024-03-01'),
                    rating: 0,
                    description: "A practical guide to building good habits and breaking bad ones through small, incremental changes."
                },
                {
                    id: 4,
                    title: "The Silent Patient",
                    author: "Alex Michaelides",
                    genre: "mystery",
                    pages: 336,
                    currentPage: 120,
                    status: "currently-reading",
                    dateAdded: new Date('2024-02-20'),
                    rating: 0,
                    description: "A psychological thriller about a woman who refuses to speak after allegedly murdering her husband."
                },
                {
                    id: 5,
                    title: "Educated",
                    author: "Tara Westover",
                    genre: "biography",
                    pages: 334,
                    currentPage: 334,
                    status: "completed",
                    dateAdded: new Date('2024-01-01'),
                    dateCompleted: new Date('2024-01-20'),
                    rating: 5,
                    description: "A memoir about education, family, and the struggle between loyalty and independence."
                }
            ];

            this.state.readingSessions = [
                { date: new Date('2024-03-01'), minutes: 45, pages: 15 },
                { date: new Date('2024-03-02'), minutes: 30, pages: 10 },
                { date: new Date('2024-03-03'), minutes: 60, pages: 20 },
                { date: new Date('2024-03-04'), minutes: 25, pages: 8 },
                { date: new Date('2024-03-05'), minutes: 40, pages: 12 }
            ];

            this.saveToStorage();
        }
    },

    // Update statistics
    updateStats() {
        const completedBooks = this.state.books.filter(book => book.status === 'completed').length;
        const currentlyReading = this.state.books.filter(book => book.status === 'currently-reading').length;
        const totalReadingTime = this.state.readingSessions.reduce((total, session) => total + session.minutes, 0);
        const readingStreak = this.calculateReadingStreak();

        // Update stats on all pages
        this.updateElement('books-read', completedBooks);
        this.updateElement('dashboard-books-read', completedBooks);
        this.updateElement('profile-books-read', completedBooks);
        this.updateElement('completed-books', completedBooks);

        this.updateElement('reading-time', Math.round(totalReadingTime / 60));
        this.updateElement('dashboard-reading-time', Math.round(totalReadingTime / 60));
        this.updateElement('profile-reading-time', Math.round(totalReadingTime / 60));

        this.updateElement('current-books', currentlyReading);
        this.updateElement('dashboard-current-books', currentlyReading);
        this.updateElement('reading-books', currentlyReading);

        this.updateElement('dashboard-streak', readingStreak);
        this.updateElement('profile-streak', readingStreak);

        this.updateElement('total-books', this.state.books.length);
        this.updateElement('wishlist-books', this.state.books.filter(book => book.status === 'want-to-read').length);

        // Update reading goal
        this.updateElement('reading-goal', this.state.goals.yearly);
    },

    // Calculate reading streak
    calculateReadingStreak() {
        if (this.state.readingSessions.length === 0) return 0;

        const today = new Date();
        const sessions = this.state.readingSessions
            .map(session => new Date(session.date))
            .sort((a, b) => b - a);

        let streak = 0;
        let currentDate = new Date(today);

        for (let session of sessions) {
            const sessionDate = new Date(session);
            sessionDate.setHours(0, 0, 0, 0);
            currentDate.setHours(0, 0, 0, 0);

            const diffDays = Math.floor((currentDate - sessionDate) / (1000 * 60 * 60 * 24));

            if (diffDays === streak) {
                streak++;
                currentDate.setDate(currentDate.getDate() - 1);
            } else if (diffDays > streak) {
                break;
            }
        }

        return streak;
    },

    // Update element text content
    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    },

    // Setup page-specific event listeners
    setupPageSpecificEvents() {
        // Get current page
        const currentPage = window.location.pathname.split('/').pop() || 'index.html';

        switch (currentPage) {
            case 'index.html':
            case '':
                this.setupHomePage();
                break;
            case 'dashboard.html':
                this.setupDashboardPage();
                break;
            case 'library.html':
                this.setupLibraryPage();
                break;
            case 'contact.html':
                this.setupContactPage();
                break;
            case 'profile.html':
                this.setupProfilePage();
                break;
        }
    },

    // Setup home page functionality
    setupHomePage() {
        this.loadFeaturedBooks();
        this.animateStats();
    },

    // Load featured books on home page
    loadFeaturedBooks() {
        const featuredBooksGrid = document.getElementById('featured-books-grid');
        if (!featuredBooksGrid) return;

        const featuredBooks = this.state.books.slice(0, 3);
        featuredBooksGrid.innerHTML = '';

        featuredBooks.forEach(book => {
            const bookCard = this.createBookCard(book);
            featuredBooksGrid.appendChild(bookCard);
        });
    },

    // Create book card element
    createBookCard(book) {
        const card = document.createElement('div');
        card.className = 'book-card';
        card.setAttribute('data-book-id', book.id);

        const progress = book.pages > 0 ? Math.round((book.currentPage / book.pages) * 100) : 0;
        const statusColors = {
            'completed': '#10B981',
            'currently-reading': '#00BFFF',
            'want-to-read': '#F59E0B',
            'on-hold': '#6B7280'
        };

        card.innerHTML = `
            <div class="book-cover" style="background: linear-gradient(135deg, ${statusColors[book.status]}, ${statusColors[book.status]}CC);">
                📚
            </div>
            <div class="book-info">
                <h3>${book.title}</h3>
                <p class="book-author">by ${book.author}</p>
                <div class="book-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${progress}%"></div>
                    </div>
                    <span class="progress-text">${progress}% complete</span>
                </div>
            </div>
        `;

        card.addEventListener('click', () => {
            this.showBookDetails(book);
        });

        return card;
    },

    // Show book details modal
    showBookDetails(book) {
        // This will be implemented in library.js for the library page
        // For now, just show a notification
        this.showNotification(`Viewing details for "${book.title}"`, 'info');
    },

    // Animate statistics on page load
    animateStats() {
        const statNumbers = document.querySelectorAll('.stat-number');
        
        statNumbers.forEach(stat => {
            const finalValue = parseInt(stat.textContent) || 0;
            let currentValue = 0;
            const increment = Math.ceil(finalValue / 30);
            
            const timer = setInterval(() => {
                currentValue += increment;
                if (currentValue >= finalValue) {
                    currentValue = finalValue;
                    clearInterval(timer);
                }
                stat.textContent = currentValue;
            }, 50);
        });
    },

    // Setup dashboard page functionality
    setupDashboardPage() {
        this.loadCurrentlyReading();
        this.loadRecentActivity();
        this.setupCharts();
        this.setupAddBookModal();
    },

    // Load currently reading books
    loadCurrentlyReading() {
        const currentlyReadingGrid = document.getElementById('currently-reading-grid');
        if (!currentlyReadingGrid) return;

        const currentBooks = this.state.books.filter(book => book.status === 'currently-reading');
        currentlyReadingGrid.innerHTML = '';

        if (currentBooks.length === 0) {
            currentlyReadingGrid.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📖</div>
                    <h3>No books in progress</h3>
                    <p>Start reading a book to see it here!</p>
                </div>
            `;
            return;
        }

        currentBooks.forEach(book => {
            const bookCard = this.createBookCard(book);
            currentlyReadingGrid.appendChild(bookCard);
        });
    },

    // Load recent activity
    loadRecentActivity() {
        const activityList = document.getElementById('activity-list');
        if (!activityList) return;

        const recentSessions = this.state.readingSessions
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 5);

        activityList.innerHTML = '';

        recentSessions.forEach(session => {
            const activityItem = document.createElement('div');
            activityItem.className = 'activity-item';
            
            const date = new Date(session.date);
            const formattedDate = date.toLocaleDateString();
            
            activityItem.innerHTML = `
                <div class="activity-icon">📖</div>
                <div class="activity-content">
                    <p>Read for ${session.minutes} minutes</p>
                    <span class="activity-date">${formattedDate}</span>
                </div>
                <div class="activity-stats">
                    <span>${session.pages} pages</span>
                </div>
            `;
            
            activityList.appendChild(activityItem);
        });
    },

    // Setup charts (placeholder for Chart.js integration)
    setupCharts() {
        // This would integrate with Chart.js for real charts
        // For now, we'll create placeholder charts
        this.createProgressChart();
        this.createGenreChart();
    },

    // Create progress chart
    createProgressChart() {
        const canvas = document.getElementById('progressChart');
        if (!canvas) return;

        // Placeholder chart implementation
        const ctx = canvas.getContext('2d');
        if (ctx) {
            // Simple placeholder visualization
            ctx.fillStyle = '#00BFFF';
            ctx.fillRect(10, 10, 100, 50);
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '14px Inter';
            ctx.fillText('Progress Chart', 20, 40);
        }
    },

    // Create genre chart
    createGenreChart() {
        const canvas = document.getElementById('genreChart');
        if (!canvas) return;

        // Placeholder chart implementation
        const ctx = canvas.getContext('2d');
        if (ctx) {
            // Simple placeholder visualization
            ctx.fillStyle = '#FF6B35';
            ctx.fillRect(10, 10, 100, 50);
            ctx.fillStyle = '#FFFFFF';
            ctx.font = '14px Inter';
            ctx.fillText('Genre Chart', 20, 40);
        }
    },

    // Setup add book modal
    setupAddBookModal() {
        const addBookBtn = document.getElementById('add-book-btn');
        const modal = document.getElementById('add-book-modal');
        const closeBtn = document.getElementById('modal-close');
        const cancelBtn = document.getElementById('cancel-add-book');
        const form = document.getElementById('add-book-form');

        if (addBookBtn && modal) {
            addBookBtn.addEventListener('click', () => {
                this.showModal(modal);
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.hideModal(modal);
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.hideModal(modal);
            });
        }

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addNewBook(form);
            });
        }
    },

    // Add new book
    addNewBook(form) {
        const formData = new FormData(form);
        const newBook = {
            id: Date.now(),
            title: formData.get('title'),
            author: formData.get('author'),
            genre: formData.get('genre'),
            pages: parseInt(formData.get('pages')),
            currentPage: 0,
            status: 'want-to-read',
            dateAdded: new Date(),
            rating: 0,
            description: formData.get('description') || ''
        };

        this.state.books.push(newBook);
        this.saveToStorage();
        this.updateStats();
        this.loadCurrentlyReading();
        this.hideModal(document.getElementById('add-book-modal'));
        this.showNotification(`"${newBook.title}" added to your library!`, 'success');
        form.reset();
    },

    // Show modal
    showModal(modal) {
        if (modal) {
            modal.classList.add('active');
            document.body.classList.add('no-scroll');
        }
    },

    // Hide modal
    hideModal(modal) {
        if (modal) {
            modal.classList.remove('active');
            document.body.classList.remove('no-scroll');
        }
    },

    // Setup contact page functionality
    setupContactPage() {
        this.setupContactForm();
        this.setupFAQ();
    },

    // Setup contact form
    setupContactForm() {
        const form = document.getElementById('contact-form');
        const messageTextarea = document.getElementById('message');
        const charCount = document.getElementById('char-count');

        if (messageTextarea && charCount) {
            messageTextarea.addEventListener('input', () => {
                const count = messageTextarea.value.length;
                charCount.textContent = count;
                
                if (count > 1000) {
                    charCount.style.color = '#EF4444';
                } else {
                    charCount.style.color = '';
                }
            });
        }

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitContactForm(form);
            });
        }
    },

    // Submit contact form
    submitContactForm(form) {
        const submitBtn = document.getElementById('submit-btn');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');

        // Show loading state
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline';
        submitBtn.disabled = true;

        // Simulate form submission
        setTimeout(() => {
            // Hide form and show success message
            form.style.display = 'none';
            document.getElementById('success-message').style.display = 'block';
            
            // Reset button state
            btnText.style.display = 'inline';
            btnLoading.style.display = 'none';
            submitBtn.disabled = false;
            
            this.showNotification('Message sent successfully!', 'success');
        }, 2000);

        // Setup send another message button
        const sendAnotherBtn = document.getElementById('send-another');
        if (sendAnotherBtn) {
            sendAnotherBtn.addEventListener('click', () => {
                form.style.display = 'block';
                document.getElementById('success-message').style.display = 'none';
                form.reset();
                document.getElementById('char-count').textContent = '0';
            });
        }
    },

    // Setup FAQ functionality
    setupFAQ() {
        const faqQuestions = document.querySelectorAll('.faq-question');
        
        faqQuestions.forEach(question => {
            question.addEventListener('click', () => {
                const faqId = question.getAttribute('data-faq');
                const answer = document.getElementById(`faq-${faqId}`);
                
                // Toggle active state
                question.classList.toggle('active');
                answer.classList.toggle('active');
                
                // Close other FAQ items
                faqQuestions.forEach(otherQuestion => {
                    if (otherQuestion !== question) {
                        otherQuestion.classList.remove('active');
                        const otherId = otherQuestion.getAttribute('data-faq');
                        const otherAnswer = document.getElementById(`faq-${otherId}`);
                        if (otherAnswer) {
                            otherAnswer.classList.remove('active');
                        }
                    }
                });
            });
        });
    },

    // Setup profile page functionality
    setupProfilePage() {
        this.setupProfileTabs();
        this.setupProfileForms();
        this.setupAvatarModal();
        this.loadAchievements();
    },

    // Setup profile tabs
    setupProfileTabs() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.getAttribute('data-tab');
                
                // Remove active class from all tabs and contents
                tabBtns.forEach(b => b.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                
                // Add active class to clicked tab and corresponding content
                btn.classList.add('active');
                const targetContent = document.getElementById(`${targetTab}-tab`);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            });
        });
    },

    // Setup profile forms
    setupProfileForms() {
        // Personal info form
        const personalForm = document.getElementById('personal-info-form');
        if (personalForm) {
            personalForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.savePersonalInfo(personalForm);
            });
        }

        // Preferences
        const savePreferencesBtn = document.getElementById('save-preferences');
        if (savePreferencesBtn) {
            savePreferencesBtn.addEventListener('click', () => {
                this.savePreferences();
            });
        }

        // Goals
        const saveGoalsBtn = document.getElementById('save-goals');
        if (saveGoalsBtn) {
            saveGoalsBtn.addEventListener('click', () => {
                this.saveGoals();
            });
        }

        // Data export buttons
        this.setupDataExport();
    },

    // Save personal info
    savePersonalInfo(form) {
        const formData = new FormData(form);
        // In a real app, this would save to a backend
        this.showNotification('Personal information saved!', 'success');
    },

    // Save preferences
    savePreferences() {
        // Get all preference values
        const themePreference = document.getElementById('theme-preference')?.value;
        const defaultView = document.getElementById('default-view')?.value;
        const readingReminders = document.getElementById('reading-reminders')?.checked;
        const goalNotifications = document.getElementById('goal-notifications')?.checked;
        const achievementAlerts = document.getElementById('achievement-alerts')?.checked;
        const analyticsTracking = document.getElementById('analytics-tracking')?.checked;
        const dataBackup = document.getElementById('data-backup')?.checked;

        // Update state
        if (themePreference) this.state.preferences.theme = themePreference;
        if (defaultView) this.state.preferences.defaultView = defaultView;
        
        this.state.preferences.notifications = {
            reading: readingReminders,
            goals: goalNotifications,
            achievements: achievementAlerts
        };
        
        this.state.preferences.privacy = {
            analytics: analyticsTracking,
            backup: dataBackup
        };

        this.saveToStorage();
        this.showNotification('Preferences saved!', 'success');

        // Apply theme change if needed
        if (themePreference) {
            this.initializeTheme();
        }
    },

    // Save goals
    saveGoals() {
        const yearlyGoal = document.getElementById('yearly-goal')?.value;
        const monthlyGoal = document.getElementById('monthly-goal')?.value;
        const dailyGoal = document.getElementById('daily-goal')?.value;
        const streakGoal = document.getElementById('streak-goal')?.value;

        if (yearlyGoal) this.state.goals.yearly = parseInt(yearlyGoal);
        if (monthlyGoal) this.state.goals.monthly = parseInt(monthlyGoal);
        if (dailyGoal) this.state.goals.daily = parseInt(dailyGoal);
        if (streakGoal) this.state.goals.streak = parseInt(streakGoal);

        this.saveToStorage();
        this.updateStats();
        this.showNotification('Reading goals updated!', 'success');
    },

    // Setup data export
    setupDataExport() {
        const exportJsonBtn = document.getElementById('export-json');
        const exportCsvBtn = document.getElementById('export-csv');
        const exportPdfBtn = document.getElementById('export-pdf');

        if (exportJsonBtn) {
            exportJsonBtn.addEventListener('click', () => {
                this.exportData('json');
            });
        }

        if (exportCsvBtn) {
            exportCsvBtn.addEventListener('click', () => {
                this.exportData('csv');
            });
        }

        if (exportPdfBtn) {
            exportPdfBtn.addEventListener('click', () => {
                this.exportData('pdf');
            });
        }
    },

    // Export data
    exportData(format) {
        const data = {
            books: this.state.books,
            readingSessions: this.state.readingSessions,
            goals: this.state.goals,
            exportDate: new Date().toISOString()
        };

        let content, filename, mimeType;

        switch (format) {
            case 'json':
                content = JSON.stringify(data, null, 2);
                filename = 'khulisoreads-data.json';
                mimeType = 'application/json';
                break;
            case 'csv':
                content = this.convertToCSV(data.books);
                filename = 'khulisoreads-books.csv';
                mimeType = 'text/csv';
                break;
            case 'pdf':
                this.showNotification('PDF export feature coming soon!', 'info');
                return;
        }

        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);

        this.showNotification(`Data exported as ${format.toUpperCase()}!`, 'success');
    },

    // Convert books to CSV
    convertToCSV(books) {
        const headers = ['Title', 'Author', 'Genre', 'Pages', 'Current Page', 'Status', 'Date Added', 'Rating'];
        const rows = books.map(book => [
            book.title,
            book.author,
            book.genre,
            book.pages,
            book.currentPage,
            book.status,
            new Date(book.dateAdded).toLocaleDateString(),
            book.rating
        ]);

        return [headers, ...rows].map(row => 
            row.map(field => `"${field}"`).join(',')
        ).join('\n');
    },

    // Setup avatar modal
    setupAvatarModal() {
        const avatarEdit = document.getElementById('avatar-edit');
        const avatarModal = document.getElementById('avatar-modal');
        const avatarModalClose = document.getElementById('avatar-modal-close');
        const emojiOptions = document.querySelectorAll('.emoji-option');

        if (avatarEdit && avatarModal) {
            avatarEdit.addEventListener('click', () => {
                this.showModal(avatarModal);
            });
        }

        if (avatarModalClose) {
            avatarModalClose.addEventListener('click', () => {
                this.hideModal(avatarModal);
            });
        }

        emojiOptions.forEach(option => {
            option.addEventListener('click', () => {
                const emoji = option.getAttribute('data-emoji');
                this.updateAvatar(emoji);
                this.hideModal(avatarModal);
            });
        });
    },

    // Update avatar
    updateAvatar(emoji) {
        const avatarDisplay = document.getElementById('avatar-display');
        if (avatarDisplay) {
            avatarDisplay.textContent = emoji;
            this.showNotification('Avatar updated!', 'success');
        }
    },

    // Load achievements
    loadAchievements() {
        const achievementsGrid = document.getElementById('achievements-grid');
        if (!achievementsGrid) return;

        const achievements = [
            { id: 1, icon: '📚', title: 'First Book', description: 'Complete your first book', unlocked: this.state.books.some(book => book.status === 'completed') },
            { id: 2, icon: '🔥', title: 'Week Streak', description: 'Read for 7 consecutive days', unlocked: this.calculateReadingStreak() >= 7 },
            { id: 3, icon: '📖', title: 'Bookworm', description: 'Read 10 books', unlocked: this.state.books.filter(book => book.status === 'completed').length >= 10 },
            { id: 4, icon: '🎯', title: 'Goal Achiever', description: 'Reach your yearly reading goal', unlocked: false },
            { id: 5, icon: '⭐', title: 'Reviewer', description: 'Rate 5 books', unlocked: this.state.books.filter(book => book.rating > 0).length >= 5 },
            { id: 6, icon: '🌟', title: 'Diverse Reader', description: 'Read books from 5 different genres', unlocked: false }
        ];

        achievementsGrid.innerHTML = '';

        achievements.forEach(achievement => {
            const achievementCard = document.createElement('div');
            achievementCard.className = `achievement-card ${achievement.unlocked ? 'unlocked' : ''}`;
            
            achievementCard.innerHTML = `
                <div class="achievement-icon">${achievement.icon}</div>
                <h4>${achievement.title}</h4>
                <p>${achievement.description}</p>
            `;
            
            achievementsGrid.appendChild(achievementCard);
        });
    },

    // Check for new achievements
    checkAchievements() {
        // This would check for newly unlocked achievements
        // and show notifications for them
    },

    // Setup library page functionality
    setupLibraryPage() {
        // This will be implemented in library.js
    },

    // Show notification
    showNotification(message, type = 'info') {
        const container = document.getElementById('notification-container');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };

        notification.innerHTML = `
            <div class="notification-header">
                <span class="notification-title">${icons[type]} ${type.charAt(0).toUpperCase() + type.slice(1)}</span>
                <button class="notification-close">&times;</button>
            </div>
            <div class="notification-message">${message}</div>
        `;

        container.appendChild(notification);

        // Show notification
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);

        // Setup close button
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => {
            this.hideNotification(notification);
        });

        // Auto hide after 5 seconds
        setTimeout(() => {
            this.hideNotification(notification);
        }, 5000);
    },

    // Hide notification
    hideNotification(notification) {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }
};

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    KhulisoReads.init();
});

// Export for use in other files
window.KhulisoReads = KhulisoReads;

