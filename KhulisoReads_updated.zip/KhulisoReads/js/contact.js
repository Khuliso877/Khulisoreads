// ===== CONTACT SPECIFIC JAVASCRIPT =====

// Contact page functionality
const Contact = {
    formData: {},
    validationRules: {
        firstName: {
            required: true,
            minLength: 2,
            pattern: /^[a-zA-Z\s]+$/
        },
        lastName: {
            required: true,
            minLength: 2,
            pattern: /^[a-zA-Z\s]+$/
        },
        email: {
            required: true,
            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        },
        subject: {
            required: true
        },
        message: {
            required: true,
            minLength: 10,
            maxLength: 1000
        },
        privacy: {
            required: true
        }
    },

    init() {
        this.setupFormValidation();
        this.setupCharacterCounter();
        this.setupFormSubmission();
        this.setupFAQ();
        this.loadFormData();
    },

    // Setup form validation
    setupFormValidation() {
        const form = document.getElementById('contact-form');
        if (!form) return;

        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            // Real-time validation
            input.addEventListener('blur', () => {
                this.validateField(input);
            });

            input.addEventListener('input', () => {
                // Clear error state on input
                this.clearFieldError(input);
                
                // Save form data
                this.saveFormData();
            });
        });

        // Validate on form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            if (this.validateForm()) {
                this.submitForm();
            }
        });
    },

    // Validate individual field
    validateField(field) {
        const fieldName = field.name;
        const value = field.value.trim();
        const rules = this.validationRules[fieldName];
        
        if (!rules) return true;

        let isValid = true;
        let errorMessage = '';

        // Required validation
        if (rules.required && !value) {
            isValid = false;
            errorMessage = 'This field is required';
        }
        // Checkbox validation (for privacy policy)
        else if (field.type === 'checkbox' && rules.required && !field.checked) {
            isValid = false;
            errorMessage = 'You must agree to the privacy policy';
        }
        // Email validation
        else if (rules.pattern && value && !rules.pattern.test(value)) {
            isValid = false;
            if (fieldName === 'email') {
                errorMessage = 'Please enter a valid email address';
            } else if (fieldName === 'firstName' || fieldName === 'lastName') {
                errorMessage = 'Please enter only letters and spaces';
            } else {
                errorMessage = 'Please enter a valid value';
            }
        }
        // Length validation
        else if (rules.minLength && value.length < rules.minLength) {
            isValid = false;
            errorMessage = `Must be at least ${rules.minLength} characters`;
        }
        else if (rules.maxLength && value.length > rules.maxLength) {
            isValid = false;
            errorMessage = `Must be no more than ${rules.maxLength} characters`;
        }

        if (!isValid) {
            this.showFieldError(field, errorMessage);
        } else {
            this.clearFieldError(field);
        }

        return isValid;
    },

    // Show field error
    showFieldError(field, message) {
        const errorElement = document.getElementById(`${field.name}-error`);
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
        
        field.classList.add('error');
        field.style.borderColor = '#EF4444';
    },

    // Clear field error
    clearFieldError(field) {
        const errorElement = document.getElementById(`${field.name}-error`);
        if (errorElement) {
            errorElement.textContent = '';
            errorElement.style.display = 'none';
        }
        
        field.classList.remove('error');
        field.style.borderColor = '';
    },

    // Validate entire form
    validateForm() {
        const form = document.getElementById('contact-form');
        if (!form) return false;

        const inputs = form.querySelectorAll('input, select, textarea');
        let isFormValid = true;

        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isFormValid = false;
            }
        });

        return isFormValid;
    },

    // Setup character counter
    setupCharacterCounter() {
        const messageTextarea = document.getElementById('message');
        const charCount = document.getElementById('char-count');
        
        if (messageTextarea && charCount) {
            const updateCounter = () => {
                const count = messageTextarea.value.length;
                const maxLength = 1000;
                
                charCount.textContent = count;
                
                // Change color based on character count
                if (count > maxLength) {
                    charCount.style.color = '#EF4444';
                    messageTextarea.style.borderColor = '#EF4444';
                } else if (count > maxLength * 0.9) {
                    charCount.style.color = '#F59E0B';
                    messageTextarea.style.borderColor = '#F59E0B';
                } else {
                    charCount.style.color = '';
                    messageTextarea.style.borderColor = '';
                }
            };

            messageTextarea.addEventListener('input', updateCounter);
            updateCounter(); // Initial count
        }
    },

    // Setup form submission
    setupFormSubmission() {
        const form = document.getElementById('contact-form');
        const submitBtn = document.getElementById('submit-btn');
        const btnText = submitBtn?.querySelector('.btn-text');
        const btnLoading = submitBtn?.querySelector('.btn-loading');

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                
                if (this.validateForm()) {
                    // Show loading state
                    if (btnText) btnText.style.display = 'none';
                    if (btnLoading) btnLoading.style.display = 'inline';
                    if (submitBtn) submitBtn.disabled = true;

                    // Simulate form submission
                    setTimeout(() => {
                        this.handleFormSuccess();
                        
                        // Reset button state
                        if (btnText) btnText.style.display = 'inline';
                        if (btnLoading) btnLoading.style.display = 'none';
                        if (submitBtn) submitBtn.disabled = false;
                    }, 2000);
                }
            });
        }

        // Setup reset button
        const resetBtn = form?.querySelector('button[type="reset"]');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetForm();
            });
        }
    },

    // Submit form
    submitForm() {
        // In a real application, this would send data to a server
        const formData = this.getFormData();
        
        // Simulate API call
        console.log('Submitting form data:', formData);
        
        // Clear saved form data
        this.clearSavedFormData();
        
        window.KhulisoReads?.showNotification('Message sent successfully!', 'success');
    },

    // Handle form success
    handleFormSuccess() {
        const form = document.getElementById('contact-form');
        const successMessage = document.getElementById('success-message');
        
        if (form && successMessage) {
            form.style.display = 'none';
            successMessage.style.display = 'block';
            
            // Setup "Send Another Message" button
            const sendAnotherBtn = document.getElementById('send-another');
            if (sendAnotherBtn) {
                sendAnotherBtn.addEventListener('click', () => {
                    this.resetToForm();
                });
            }
        }
    },

    // Reset to form view
    resetToForm() {
        const form = document.getElementById('contact-form');
        const successMessage = document.getElementById('success-message');
        
        if (form && successMessage) {
            form.style.display = 'block';
            successMessage.style.display = 'none';
            this.resetForm();
        }
    },

    // Reset form
    resetForm() {
        const form = document.getElementById('contact-form');
        if (!form) return;

        form.reset();
        
        // Clear all error states
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            this.clearFieldError(input);
        });

        // Reset character counter
        const charCount = document.getElementById('char-count');
        if (charCount) {
            charCount.textContent = '0';
            charCount.style.color = '';
        }

        // Clear saved form data
        this.clearSavedFormData();
        
        window.KhulisoReads?.showNotification('Form reset', 'info');
    },

    // Get form data
    getFormData() {
        const form = document.getElementById('contact-form');
        if (!form) return {};

        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        return data;
    },

    // Save form data to localStorage
    saveFormData() {
        const data = this.getFormData();
        try {
            localStorage.setItem('contactFormData', JSON.stringify(data));
        } catch (error) {
            console.error('Error saving form data:', error);
        }
    },

    // Load form data from localStorage
    loadFormData() {
        try {
            const savedData = localStorage.getItem('contactFormData');
            if (savedData) {
                const data = JSON.parse(savedData);
                this.populateForm(data);
            }
        } catch (error) {
            console.error('Error loading form data:', error);
        }
    },

    // Populate form with data
    populateForm(data) {
        const form = document.getElementById('contact-form');
        if (!form) return;

        Object.keys(data).forEach(key => {
            const field = form.querySelector(`[name="${key}"]`);
            if (field) {
                if (field.type === 'checkbox') {
                    field.checked = data[key] === 'on';
                } else {
                    field.value = data[key];
                }
            }
        });

        // Update character counter if message is populated
        const messageField = form.querySelector('[name="message"]');
        const charCount = document.getElementById('char-count');
        if (messageField && charCount) {
            charCount.textContent = messageField.value.length;
        }
    },

    // Clear saved form data
    clearSavedFormData() {
        try {
            localStorage.removeItem('contactFormData');
        } catch (error) {
            console.error('Error clearing form data:', error);
        }
    },

    // Setup FAQ functionality
    setupFAQ() {
        const faqQuestions = document.querySelectorAll('.faq-question');
        
        faqQuestions.forEach(question => {
            question.addEventListener('click', () => {
                const faqId = question.getAttribute('data-faq');
                const answer = document.getElementById(`faq-${faqId}`);
                const icon = question.querySelector('.faq-icon');
                
                // Toggle current FAQ
                const isActive = question.classList.contains('active');
                
                // Close all FAQs
                faqQuestions.forEach(q => {
                    q.classList.remove('active');
                    const qId = q.getAttribute('data-faq');
                    const qAnswer = document.getElementById(`faq-${qId}`);
                    if (qAnswer) {
                        qAnswer.classList.remove('active');
                    }
                });
                
                // Open clicked FAQ if it wasn't active
                if (!isActive) {
                    question.classList.add('active');
                    if (answer) {
                        answer.classList.add('active');
                    }
                }
            });
        });
    },

    // Auto-save form data periodically
    startAutoSave() {
        setInterval(() => {
            this.saveFormData();
        }, 30000); // Save every 30 seconds
    },

    // Validate email format
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    // Check if form has unsaved changes
    hasUnsavedChanges() {
        const currentData = this.getFormData();
        const savedData = localStorage.getItem('contactFormData');
        
        if (!savedData) return Object.keys(currentData).length > 0;
        
        try {
            const parsedSavedData = JSON.parse(savedData);
            return JSON.stringify(currentData) !== JSON.stringify(parsedSavedData);
        } catch {
            return true;
        }
    },

    // Warn user about unsaved changes
    setupUnloadWarning() {
        window.addEventListener('beforeunload', (e) => {
            if (this.hasUnsavedChanges()) {
                e.preventDefault();
                e.returnValue = 'You have unsaved changes. Are you sure you want to leave?';
                return e.returnValue;
            }
        });
    }
};

// Initialize contact page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for main app to initialize
    setTimeout(() => {
        Contact.init();
        Contact.startAutoSave();
        Contact.setupUnloadWarning();
    }, 100);
});

// Export for global access
window.Contact = Contact;

