// ===== LIBRARY SPECIFIC JAVASCRIPT =====

// Library functionality
const Library = {
    currentView: 'grid',
    currentFilter: {
        search: '',
        genre: '',
        status: '',
        sort: 'title'
    },
    currentPage: 1,
    booksPerPage: 12,
    filteredBooks: [],

    init() {
        this.setupSearch();
        this.setupFilters();
        this.setupViewToggle();
        this.setupPagination();
        this.setupModals();
        this.loadLibrary();
        this.updateLibraryStats();
    },

    // Setup search functionality
    setupSearch() {
        const searchInput = document.getElementById('search-input');
        const searchBtn = document.getElementById('search-btn');
        const clearSearchBtn = document.getElementById('clear-search');

        if (searchInput) {
            // Real-time search with debouncing
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.currentFilter.search = e.target.value.toLowerCase();
                    this.filterAndDisplayBooks();
                }, 300);
            });

            // Search on Enter key
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.currentFilter.search = e.target.value.toLowerCase();
                    this.filterAndDisplayBooks();
                }
            });
        }

        if (searchBtn) {
            searchBtn.addEventListener('click', () => {
                if (searchInput) {
                    this.currentFilter.search = searchInput.value.toLowerCase();
                    this.filterAndDisplayBooks();
                }
            });
        }

        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', () => {
                this.clearSearch();
            });
        }
    },

    // Setup filter functionality
    setupFilters() {
        const filterToggle = document.getElementById('filter-toggle');
        const filtersPanel = document.getElementById('filters-panel');
        const genreFilter = document.getElementById('genre-filter');
        const statusFilter = document.getElementById('status-filter');
        const sortFilter = document.getElementById('sort-filter');
        const clearFilters = document.getElementById('clear-filters');

        if (filterToggle && filtersPanel) {
            filterToggle.addEventListener('click', () => {
                filtersPanel.classList.toggle('active');
            });
        }

        if (genreFilter) {
            genreFilter.addEventListener('change', (e) => {
                this.currentFilter.genre = e.target.value;
                this.filterAndDisplayBooks();
            });
        }

        if (statusFilter) {
            statusFilter.addEventListener('change', (e) => {
                this.currentFilter.status = e.target.value;
                this.filterAndDisplayBooks();
            });
        }

        if (sortFilter) {
            sortFilter.addEventListener('change', (e) => {
                this.currentFilter.sort = e.target.value;
                this.filterAndDisplayBooks();
            });
        }

        if (clearFilters) {
            clearFilters.addEventListener('click', () => {
                this.clearAllFilters();
            });
        }
    },

    // Setup view toggle
    setupViewToggle() {
        const viewBtns = document.querySelectorAll('.view-btn');
        const booksGrid = document.getElementById('books-grid');
        const booksList = document.getElementById('books-list');

        viewBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const view = btn.getAttribute('data-view');
                this.switchView(view);
                
                // Update active button
                viewBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            });
        });
    },

    // Switch between grid and list view
    switchView(view) {
        this.currentView = view;
        const booksGrid = document.getElementById('books-grid');
        const booksList = document.getElementById('books-list');

        if (view === 'grid') {
            if (booksGrid) booksGrid.style.display = 'grid';
            if (booksList) booksList.style.display = 'none';
        } else {
            if (booksGrid) booksGrid.style.display = 'none';
            if (booksList) booksList.style.display = 'block';
        }

        this.displayBooks();
    },

    // Setup pagination
    setupPagination() {
        const prevBtn = document.getElementById('prev-page');
        const nextBtn = document.getElementById('next-page');

        if (prevBtn) {
            prevBtn.addEventListener('click', () => {
                if (this.currentPage > 1) {
                    this.currentPage--;
                    this.displayBooks();
                    this.updatePagination();
                }
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', () => {
                const totalPages = Math.ceil(this.filteredBooks.length / this.booksPerPage);
                if (this.currentPage < totalPages) {
                    this.currentPage++;
                    this.displayBooks();
                    this.updatePagination();
                }
            });
        }
    },

    // Setup modals
    setupModals() {
        this.setupBookDetailModal();
        this.setupAddBookModal();
    },

    // Setup book detail modal
    setupBookDetailModal() {
        const modal = document.getElementById('book-detail-modal');
        const closeBtn = document.getElementById('book-modal-close');
        const updateProgressBtn = document.getElementById('update-progress');
        const editBookBtn = document.getElementById('edit-book');
        const removeBookBtn = document.getElementById('remove-book');
        const statusSelect = document.getElementById('book-status');

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.hideModal(modal);
            });
        }

        if (updateProgressBtn) {
            updateProgressBtn.addEventListener('click', () => {
                this.updateBookProgress();
            });
        }

        if (editBookBtn) {
            editBookBtn.addEventListener('click', () => {
                this.editCurrentBook();
            });
        }

        if (removeBookBtn) {
            removeBookBtn.addEventListener('click', () => {
                this.removeCurrentBook();
            });
        }

        if (statusSelect) {
            statusSelect.addEventListener('change', (e) => {
                this.updateBookStatus(e.target.value);
            });
        }
    },

    // Setup add book modal
    setupAddBookModal() {
        const addFirstBookBtn = document.getElementById('add-first-book');
        const modal = document.getElementById('add-book-modal');
        const closeBtn = document.getElementById('add-modal-close');
        const cancelBtn = document.getElementById('cancel-add');
        const form = document.getElementById('add-book-form');

        if (addFirstBookBtn) {
            addFirstBookBtn.addEventListener('click', () => {
                this.showModal(modal);
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.hideModal(modal);
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.hideModal(modal);
            });
        }

        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addNewBook(form);
            });
        }
    },

    // Load library
    loadLibrary() {
        this.filteredBooks = this.getAllBooks();
        this.filterAndDisplayBooks();
    },

    // Get all books
    getAllBooks() {
        return window.KhulisoReads?.state?.books || [];
    },

    // Filter and display books
    filterAndDisplayBooks() {
        let books = this.getAllBooks();

        // Apply search filter
        if (this.currentFilter.search) {
            books = books.filter(book => 
                book.title.toLowerCase().includes(this.currentFilter.search) ||
                book.author.toLowerCase().includes(this.currentFilter.search) ||
                book.genre.toLowerCase().includes(this.currentFilter.search)
            );
        }

        // Apply genre filter
        if (this.currentFilter.genre) {
            books = books.filter(book => book.genre === this.currentFilter.genre);
        }

        // Apply status filter
        if (this.currentFilter.status) {
            books = books.filter(book => book.status === this.currentFilter.status);
        }

        // Apply sorting
        books = this.sortBooks(books, this.currentFilter.sort);

        this.filteredBooks = books;
        this.currentPage = 1; // Reset to first page
        this.displayBooks();
        this.updatePagination();
        this.updateLibraryStats();
    },

    // Sort books
    sortBooks(books, sortBy) {
        return books.sort((a, b) => {
            switch (sortBy) {
                case 'title':
                    return a.title.localeCompare(b.title);
                case 'author':
                    return a.author.localeCompare(b.author);
                case 'date-added':
                    return new Date(b.dateAdded) - new Date(a.dateAdded);
                case 'rating':
                    return b.rating - a.rating;
                case 'progress':
                    const progressA = a.pages > 0 ? (a.currentPage / a.pages) : 0;
                    const progressB = b.pages > 0 ? (b.currentPage / b.pages) : 0;
                    return progressB - progressA;
                default:
                    return 0;
            }
        });
    },

    // Display books
    displayBooks() {
        const startIndex = (this.currentPage - 1) * this.booksPerPage;
        const endIndex = startIndex + this.booksPerPage;
        const booksToShow = this.filteredBooks.slice(startIndex, endIndex);

        this.hideLoadingState();

        if (this.filteredBooks.length === 0) {
            this.showEmptyState();
            return;
        }

        this.hideEmptyState();

        if (this.currentView === 'grid') {
            this.displayBooksGrid(booksToShow);
        } else {
            this.displayBooksList(booksToShow);
        }
    },

    // Display books in grid view
    displayBooksGrid(books) {
        const booksGrid = document.getElementById('books-grid');
        if (!booksGrid) return;

        booksGrid.innerHTML = '';

        books.forEach(book => {
            const bookCard = this.createBookCard(book);
            booksGrid.appendChild(bookCard);
        });
    },

    // Display books in list view
    displayBooksList(books) {
        const booksList = document.getElementById('books-list');
        if (!booksList) return;

        booksList.innerHTML = '';

        books.forEach(book => {
            const bookItem = this.createBookListItem(book);
            booksList.appendChild(bookItem);
        });
    },

    // Create book card for grid view
    createBookCard(book) {
        const card = document.createElement('div');
        card.className = 'book-card';
        card.setAttribute('data-book-id', book.id);

        const progress = book.pages > 0 ? Math.round((book.currentPage / book.pages) * 100) : 0;
        const statusColors = {
            'completed': '#10B981',
            'currently-reading': '#00BFFF',
            'want-to-read': '#F59E0B',
            'on-hold': '#6B7280'
        };

        const statusLabels = {
            'completed': 'Completed',
            'currently-reading': 'Reading',
            'want-to-read': 'Want to Read',
            'on-hold': 'On Hold'
        };

        card.innerHTML = `
            <div class="book-cover" style="background: linear-gradient(135deg, ${statusColors[book.status]}, ${statusColors[book.status]}CC);">
                📚
            </div>
            <div class="book-info">
                <h3>${book.title}</h3>
                <p class="book-author">by ${book.author}</p>
                <p class="book-genre">${book.genre}</p>
                <div class="book-status-badge" style="background: ${statusColors[book.status]};">
                    ${statusLabels[book.status]}
                </div>
                <div class="book-progress">
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${progress}%"></div>
                    </div>
                    <span class="progress-text">${book.currentPage}/${book.pages} pages (${progress}%)</span>
                </div>
                ${book.rating > 0 ? `<div class="book-rating">${'⭐'.repeat(book.rating)}</div>` : ''}
            </div>
        `;

        card.addEventListener('click', () => {
            this.showBookDetails(book);
        });

        return card;
    },

    // Create book list item for list view
    createBookListItem(book) {
        const item = document.createElement('div');
        item.className = 'book-list-item';
        item.setAttribute('data-book-id', book.id);

        const progress = book.pages > 0 ? Math.round((book.currentPage / book.pages) * 100) : 0;
        const statusColors = {
            'completed': '#10B981',
            'currently-reading': '#00BFFF',
            'want-to-read': '#F59E0B',
            'on-hold': '#6B7280'
        };

        item.innerHTML = `
            <div class="book-list-cover">📚</div>
            <div class="book-list-info">
                <h3>${book.title}</h3>
                <p class="book-author">by ${book.author}</p>
                <p class="book-genre">${book.genre} • ${book.pages} pages</p>
            </div>
            <div class="book-list-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progress}%"></div>
                </div>
                <span class="progress-text">${progress}%</span>
            </div>
            <div class="book-list-status" style="color: ${statusColors[book.status]};">
                ${book.status.replace('-', ' ')}
            </div>
            <div class="book-list-actions">
                <button class="btn btn-sm btn-primary">View</button>
            </div>
        `;

        item.addEventListener('click', () => {
            this.showBookDetails(book);
        });

        return item;
    },

    // Show book details modal
    showBookDetails(book) {
        this.currentBook = book;
        const modal = document.getElementById('book-detail-modal');
        
        // Populate modal with book data
        this.updateElement('modal-book-title', book.title);
        this.updateElement('modal-book-author', `by ${book.author}`);
        this.updateElement('modal-book-genre', book.genre);
        this.updateElement('modal-book-pages', `${book.pages} pages`);
        this.updateElement('modal-book-description', book.description || 'No description available.');

        // Update progress
        const progress = book.pages > 0 ? (book.currentPage / book.pages) * 100 : 0;
        const progressFill = document.getElementById('modal-progress-fill');
        if (progressFill) {
            progressFill.style.width = `${progress}%`;
        }

        // Update current page input
        const currentPageInput = document.getElementById('current-page');
        if (currentPageInput) {
            currentPageInput.value = book.currentPage;
            currentPageInput.max = book.pages;
        }

        // Update status select
        const statusSelect = document.getElementById('book-status');
        if (statusSelect) {
            statusSelect.value = book.status;
        }

        this.showModal(modal);
    },

    // Update book progress
    updateBookProgress() {
        if (!this.currentBook) return;

        const currentPageInput = document.getElementById('current-page');
        const newPage = parseInt(currentPageInput.value);

        if (isNaN(newPage) || newPage < 0 || newPage > this.currentBook.pages) {
            window.KhulisoReads?.showNotification('Please enter a valid page number', 'error');
            return;
        }

        this.currentBook.currentPage = newPage;

        // Auto-update status if book is completed
        if (newPage === this.currentBook.pages && this.currentBook.status !== 'completed') {
            this.currentBook.status = 'completed';
            this.currentBook.dateCompleted = new Date();
        }

        this.saveBookChanges();
        this.updateBookProgressDisplay();
        window.KhulisoReads?.showNotification('Progress updated!', 'success');
    },

    // Update book status
    updateBookStatus(newStatus) {
        if (!this.currentBook) return;

        this.currentBook.status = newStatus;

        if (newStatus === 'completed' && this.currentBook.currentPage < this.currentBook.pages) {
            this.currentBook.currentPage = this.currentBook.pages;
            this.currentBook.dateCompleted = new Date();
        }

        this.saveBookChanges();
        this.updateBookProgressDisplay();
        window.KhulisoReads?.showNotification('Status updated!', 'success');
    },

    // Update book progress display in modal
    updateBookProgressDisplay() {
        if (!this.currentBook) return;

        const progress = this.currentBook.pages > 0 ? (this.currentBook.currentPage / this.currentBook.pages) * 100 : 0;
        const progressFill = document.getElementById('modal-progress-fill');
        if (progressFill) {
            progressFill.style.width = `${progress}%`;
        }

        const currentPageInput = document.getElementById('current-page');
        if (currentPageInput) {
            currentPageInput.value = this.currentBook.currentPage;
        }

        const statusSelect = document.getElementById('book-status');
        if (statusSelect) {
            statusSelect.value = this.currentBook.status;
        }
    },

    // Save book changes
    saveBookChanges() {
        if (!this.currentBook || !window.KhulisoReads) return;

        const bookIndex = window.KhulisoReads.state.books.findIndex(b => b.id === this.currentBook.id);
        if (bookIndex !== -1) {
            window.KhulisoReads.state.books[bookIndex] = { ...this.currentBook };
            window.KhulisoReads.saveToStorage();
            window.KhulisoReads.updateStats();
            this.filterAndDisplayBooks();
        }
    },

    // Edit current book
    editCurrentBook() {
        window.KhulisoReads?.showNotification('Edit functionality coming soon!', 'info');
    },

    // Remove current book
    removeCurrentBook() {
        if (!this.currentBook) return;

        const confirmed = confirm(`Are you sure you want to remove "${this.currentBook.title}" from your library?`);
        if (!confirmed) return;

        if (window.KhulisoReads) {
            const bookIndex = window.KhulisoReads.state.books.findIndex(b => b.id === this.currentBook.id);
            if (bookIndex !== -1) {
                window.KhulisoReads.state.books.splice(bookIndex, 1);
                window.KhulisoReads.saveToStorage();
                window.KhulisoReads.updateStats();
                this.filterAndDisplayBooks();
                this.hideModal(document.getElementById('book-detail-modal'));
                window.KhulisoReads.showNotification('Book removed from library', 'success');
            }
        }
    },

    // Add new book
    addNewBook(form) {
        const formData = new FormData(form);
        const newBook = {
            id: Date.now(),
            title: formData.get('title'),
            author: formData.get('author'),
            genre: formData.get('genre'),
            pages: parseInt(formData.get('pages')),
            currentPage: 0,
            status: 'want-to-read',
            dateAdded: new Date(),
            rating: 0,
            description: formData.get('description') || ''
        };

        if (window.KhulisoReads) {
            window.KhulisoReads.state.books.push(newBook);
            window.KhulisoReads.saveToStorage();
            window.KhulisoReads.updateStats();
            this.filterAndDisplayBooks();
            this.hideModal(document.getElementById('add-book-modal'));
            window.KhulisoReads.showNotification(`"${newBook.title}" added to your library!`, 'success');
            form.reset();
        }
    },

    // Clear search
    clearSearch() {
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.value = '';
        }
        this.currentFilter.search = '';
        this.filterAndDisplayBooks();
    },

    // Clear all filters
    clearAllFilters() {
        // Reset filter inputs
        const searchInput = document.getElementById('search-input');
        const genreFilter = document.getElementById('genre-filter');
        const statusFilter = document.getElementById('status-filter');
        const sortFilter = document.getElementById('sort-filter');

        if (searchInput) searchInput.value = '';
        if (genreFilter) genreFilter.value = '';
        if (statusFilter) statusFilter.value = '';
        if (sortFilter) sortFilter.value = 'title';

        // Reset filter state
        this.currentFilter = {
            search: '',
            genre: '',
            status: '',
            sort: 'title'
        };

        this.filterAndDisplayBooks();
        window.KhulisoReads?.showNotification('Filters cleared', 'info');
    },

    // Update pagination
    updatePagination() {
        const totalPages = Math.ceil(this.filteredBooks.length / this.booksPerPage);
        const prevBtn = document.getElementById('prev-page');
        const nextBtn = document.getElementById('next-page');
        const paginationNumbers = document.getElementById('pagination-numbers');

        // Update button states
        if (prevBtn) {
            prevBtn.disabled = this.currentPage === 1;
        }
        if (nextBtn) {
            nextBtn.disabled = this.currentPage === totalPages || totalPages === 0;
        }

        // Update page numbers
        if (paginationNumbers) {
            paginationNumbers.innerHTML = '';
            
            for (let i = 1; i <= totalPages; i++) {
                const pageBtn = document.createElement('button');
                pageBtn.className = `page-number ${i === this.currentPage ? 'active' : ''}`;
                pageBtn.textContent = i;
                pageBtn.addEventListener('click', () => {
                    this.currentPage = i;
                    this.displayBooks();
                    this.updatePagination();
                });
                paginationNumbers.appendChild(pageBtn);
            }
        }
    },

    // Update library stats
    updateLibraryStats() {
        const books = this.getAllBooks();
        
        this.updateElement('total-books', books.length);
        this.updateElement('completed-books', books.filter(b => b.status === 'completed').length);
        this.updateElement('reading-books', books.filter(b => b.status === 'currently-reading').length);
        this.updateElement('wishlist-books', books.filter(b => b.status === 'want-to-read').length);
    },

    // Show/hide states
    showLoadingState() {
        const loadingState = document.getElementById('loading-books');
        if (loadingState) loadingState.style.display = 'block';
    },

    hideLoadingState() {
        const loadingState = document.getElementById('loading-books');
        if (loadingState) loadingState.style.display = 'none';
    },

    showEmptyState() {
        const emptyState = document.getElementById('empty-library');
        const noResults = document.getElementById('no-results');
        
        if (this.getAllBooks().length === 0) {
            if (emptyState) emptyState.style.display = 'block';
            if (noResults) noResults.style.display = 'none';
        } else {
            if (emptyState) emptyState.style.display = 'none';
            if (noResults) noResults.style.display = 'block';
        }
    },

    hideEmptyState() {
        const emptyState = document.getElementById('empty-library');
        const noResults = document.getElementById('no-results');
        if (emptyState) emptyState.style.display = 'none';
        if (noResults) noResults.style.display = 'none';
    },

    // Utility functions
    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    },

    showModal(modal) {
        if (modal) {
            modal.classList.add('active');
            document.body.classList.add('no-scroll');
        }
    },

    hideModal(modal) {
        if (modal) {
            modal.classList.remove('active');
            document.body.classList.remove('no-scroll');
        }
    }
};

// Initialize library when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for main app to initialize
    setTimeout(() => {
        Library.init();
    }, 100);
});

// Export for global access
window.Library = Library;

