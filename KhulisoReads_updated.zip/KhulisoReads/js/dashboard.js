// ===== DASHBOARD SPECIFIC JAVASCRIPT =====

// Dashboard functionality
const Dashboard = {
    charts: {},
    
    init() {
        this.setupCharts();
        this.setupFilters();
        this.setupGoalEditing();
        this.loadDashboardData();
    },

    // Setup Chart.js charts
    setupCharts() {
        this.createProgressChart();
        this.createGenreChart();
    },

    // Create reading progress chart
    createProgressChart() {
        const canvas = document.getElementById('progressChart');
        if (!canvas || !window.Chart) {
            // Fallback if Chart.js is not loaded
            this.createFallbackChart(canvas, 'Reading Progress');
            return;
        }

        const ctx = canvas.getContext('2d');
        
        // Generate sample data for the last 30 days
        const data = this.generateProgressData();
        
        this.charts.progress = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Pages Read',
                    data: data.pages,
                    borderColor: '#00BFFF',
                    backgroundColor: 'rgba(0, 191, 255, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Reading Time (minutes)',
                    data: data.minutes,
                    borderColor: '#FF6B35',
                    backgroundColor: 'rgba(255, 107, 53, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    },

    // Create genre distribution chart
    createGenreChart() {
        const canvas = document.getElementById('genreChart');
        if (!canvas || !window.Chart) {
            // Fallback if Chart.js is not loaded
            this.createFallbackChart(canvas, 'Genre Distribution');
            return;
        }

        const ctx = canvas.getContext('2d');
        
        // Get genre data from books
        const genreData = this.getGenreDistribution();
        
        this.charts.genre = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: genreData.labels,
                datasets: [{
                    data: genreData.data,
                    backgroundColor: [
                        '#00BFFF',
                        '#FF6B35',
                        '#8B5CF6',
                        '#10B981',
                        '#F59E0B',
                        '#EF4444',
                        '#6B7280',
                        '#EC4899'
                    ],
                    borderWidth: 2,
                    borderColor: '#FFFFFF'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    },
                    title: {
                        display: false
                    }
                },
                cutout: '60%'
            }
        });
    },

    // Create fallback chart when Chart.js is not available
    createFallbackChart(canvas, title) {
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw background
        ctx.fillStyle = '#F3F4F6';
        ctx.fillRect(0, 0, width, height);
        
        // Draw title
        ctx.fillStyle = '#374151';
        ctx.font = 'bold 16px Inter';
        ctx.textAlign = 'center';
        ctx.fillText(title, width / 2, height / 2 - 20);
        
        // Draw subtitle
        ctx.fillStyle = '#6B7280';
        ctx.font = '14px Inter';
        ctx.fillText('Chart data will appear here', width / 2, height / 2 + 10);
        
        // Draw decorative elements
        ctx.fillStyle = '#00BFFF';
        ctx.beginPath();
        ctx.arc(width / 2 - 40, height / 2 + 40, 8, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.fillStyle = '#FF6B35';
        ctx.beginPath();
        ctx.arc(width / 2, height / 2 + 40, 8, 0, 2 * Math.PI);
        ctx.fill();
        
        ctx.fillStyle = '#8B5CF6';
        ctx.beginPath();
        ctx.arc(width / 2 + 40, height / 2 + 40, 8, 0, 2 * Math.PI);
        ctx.fill();
    },

    // Generate sample progress data
    generateProgressData() {
        const labels = [];
        const pages = [];
        const minutes = [];
        
        const today = new Date();
        
        for (let i = 29; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            
            // Generate realistic reading data
            const isWeekend = date.getDay() === 0 || date.getDay() === 6;
            const basePages = isWeekend ? 15 : 10;
            const baseMinutes = isWeekend ? 45 : 30;
            
            pages.push(basePages + Math.floor(Math.random() * 10));
            minutes.push(baseMinutes + Math.floor(Math.random() * 20));
        }
        
        return { labels, pages, minutes };
    },

    // Get genre distribution from books
    getGenreDistribution() {
        const books = window.KhulisoReads?.state?.books || [];
        const genreCounts = {};
        
        books.forEach(book => {
            const genre = book.genre || 'Unknown';
            genreCounts[genre] = (genreCounts[genre] || 0) + 1;
        });
        
        const labels = Object.keys(genreCounts);
        const data = Object.values(genreCounts);
        
        return { labels, data };
    },

    // Setup chart filters
    setupFilters() {
        const progressFilter = document.getElementById('progress-filter');
        const genreRefresh = document.getElementById('genre-refresh');
        
        if (progressFilter) {
            progressFilter.addEventListener('change', (e) => {
                this.updateProgressChart(e.target.value);
            });
        }
        
        if (genreRefresh) {
            genreRefresh.addEventListener('click', () => {
                this.refreshGenreChart();
            });
        }
    },

    // Update progress chart based on filter
    updateProgressChart(period) {
        if (!this.charts.progress) return;
        
        let data;
        switch (period) {
            case 'week':
                data = this.generateProgressData(7);
                break;
            case 'month':
                data = this.generateProgressData(30);
                break;
            case 'year':
                data = this.generateProgressData(365);
                break;
            default:
                data = this.generateProgressData(30);
        }
        
        this.charts.progress.data.labels = data.labels;
        this.charts.progress.data.datasets[0].data = data.pages;
        this.charts.progress.data.datasets[1].data = data.minutes;
        this.charts.progress.update();
        
        window.KhulisoReads?.showNotification(`Chart updated for ${period}`, 'info');
    },

    // Refresh genre chart
    refreshGenreChart() {
        if (!this.charts.genre) return;
        
        const genreData = this.getGenreDistribution();
        this.charts.genre.data.labels = genreData.labels;
        this.charts.genre.data.datasets[0].data = genreData.data;
        this.charts.genre.update();
        
        window.KhulisoReads?.showNotification('Genre chart refreshed', 'success');
    },

    // Setup goal editing
    setupGoalEditing() {
        const editGoalsBtn = document.getElementById('edit-goals-btn');
        
        if (editGoalsBtn) {
            editGoalsBtn.addEventListener('click', () => {
                this.showGoalEditModal();
            });
        }
    },

    // Show goal edit modal
    showGoalEditModal() {
        // Create a simple prompt for goal editing
        const currentGoal = window.KhulisoReads?.state?.goals?.yearly || 20;
        const newGoal = prompt(`Enter your yearly reading goal (current: ${currentGoal}):`, currentGoal);
        
        if (newGoal && !isNaN(newGoal) && newGoal > 0) {
            if (window.KhulisoReads) {
                window.KhulisoReads.state.goals.yearly = parseInt(newGoal);
                window.KhulisoReads.saveToStorage();
                window.KhulisoReads.updateStats();
                window.KhulisoReads.showNotification(`Yearly goal updated to ${newGoal} books!`, 'success');
                this.updateGoalProgress();
            }
        }
    },

    // Update goal progress displays
    updateGoalProgress() {
        const books = window.KhulisoReads?.state?.books || [];
        const completedBooks = books.filter(book => book.status === 'completed').length;
        const yearlyGoal = window.KhulisoReads?.state?.goals?.yearly || 20;
        
        const progress = Math.min((completedBooks / yearlyGoal) * 100, 100);
        
        // Update yearly goal progress
        const yearlyProgressBar = document.querySelector('.goal-card .progress-fill');
        const yearlyProgressText = document.querySelector('.goal-card .goal-details');
        
        if (yearlyProgressBar) {
            yearlyProgressBar.style.width = `${progress}%`;
        }
        
        if (yearlyProgressText) {
            const remaining = Math.max(yearlyGoal - completedBooks, 0);
            yearlyProgressText.innerHTML = `
                <span>${completedBooks} of ${yearlyGoal} books</span>
                <span>${remaining} books remaining</span>
            `;
        }
        
        // Update goal status
        const goalStatus = document.querySelector('.goal-card .goal-status');
        if (goalStatus) {
            goalStatus.textContent = `${Math.round(progress)}%`;
        }
    },

    // Load dashboard-specific data
    loadDashboardData() {
        this.updateGoalProgress();
        this.loadReadingStreak();
        this.updateTrendIndicators();
    },

    // Load reading streak information
    loadReadingStreak() {
        const streak = window.KhulisoReads?.calculateReadingStreak() || 0;
        const streakElement = document.getElementById('dashboard-streak');
        
        if (streakElement) {
            streakElement.textContent = streak;
            
            // Add animation for streak milestones
            if (streak > 0 && streak % 7 === 0) {
                streakElement.classList.add('animate-pulse');
                setTimeout(() => {
                    streakElement.classList.remove('animate-pulse');
                }, 2000);
            }
        }
    },

    // Update trend indicators
    updateTrendIndicators() {
        const trendElements = document.querySelectorAll('.stat-trend');
        
        trendElements.forEach((element, index) => {
            // Simulate trend data
            const trends = ['+3', '+12h', '3', 'On track'];
            const trendTypes = ['positive', 'positive', 'neutral', 'positive'];
            
            if (trends[index]) {
                element.textContent = trends[index];
                element.className = `stat-trend ${trendTypes[index]}`;
            }
        });
    },

    // Add reading session
    addReadingSession(minutes, pages) {
        if (!window.KhulisoReads) return;
        
        const session = {
            date: new Date(),
            minutes: parseInt(minutes),
            pages: parseInt(pages)
        };
        
        window.KhulisoReads.state.readingSessions.push(session);
        window.KhulisoReads.saveToStorage();
        window.KhulisoReads.loadRecentActivity();
        this.updateProgressChart('month');
        
        window.KhulisoReads.showNotification(`Reading session added: ${minutes} minutes, ${pages} pages`, 'success');
    },

    // Quick add reading session
    quickAddSession() {
        const minutes = prompt('How many minutes did you read?');
        const pages = prompt('How many pages did you read?');
        
        if (minutes && pages && !isNaN(minutes) && !isNaN(pages)) {
            this.addReadingSession(minutes, pages);
        }
    }
};

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for main app to initialize
    setTimeout(() => {
        Dashboard.init();
    }, 100);
});

// Add quick session button functionality
document.addEventListener('DOMContentLoaded', () => {
    // Create a floating action button for quick session entry
    const fab = document.createElement('button');
    fab.className = 'floating-action-btn';
    fab.innerHTML = '📖';
    fab.title = 'Quick Add Reading Session';
    fab.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #00BFFF, #0099CC);
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0, 191, 255, 0.3);
        transition: all 0.3s ease;
        z-index: 1000;
    `;
    
    fab.addEventListener('mouseenter', () => {
        fab.style.transform = 'scale(1.1)';
        fab.style.boxShadow = '0 6px 20px rgba(0, 191, 255, 0.4)';
    });
    
    fab.addEventListener('mouseleave', () => {
        fab.style.transform = 'scale(1)';
        fab.style.boxShadow = '0 4px 12px rgba(0, 191, 255, 0.3)';
    });
    
    fab.addEventListener('click', () => {
        Dashboard.quickAddSession();
    });
    
    // Only add to dashboard page
    if (window.location.pathname.includes('dashboard.html')) {
        document.body.appendChild(fab);
    }
});

// Export for global access
window.Dashboard = Dashboard;

