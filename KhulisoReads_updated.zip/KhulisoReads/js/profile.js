// ===== PROFILE SPECIFIC JAVASCRIPT =====

// Profile page functionality
const Profile = {
    currentTab: 'personal',
    achievements: [],
    
    init() {
        this.setupTabs();
        this.setupForms();
        this.setupAvatarModal();
        this.setupDataManagement();
        this.loadProfileData();
        this.loadAchievements();
        this.updateStorageInfo();
    },

    // Setup tab navigation
    setupTabs() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');

        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const targetTab = btn.getAttribute('data-tab');
                this.switchTab(targetTab);
                
                // Update active states
                tabBtns.forEach(b => b.classList.remove('active'));
                tabContents.forEach(c => c.classList.remove('active'));
                
                btn.classList.add('active');
                const targetContent = document.getElementById(`${targetTab}-tab`);
                if (targetContent) {
                    targetContent.classList.add('active');
                }
            });
        });
    },

    // Switch to specific tab
    switchTab(tabName) {
        this.currentTab = tabName;
        
        // Load tab-specific data
        switch (tabName) {
            case 'achievements':
                this.loadAchievements();
                break;
            case 'data':
                this.updateStorageInfo();
                break;
        }
    },

    // Setup form handling
    setupForms() {
        this.setupPersonalInfoForm();
        this.setupPreferencesForm();
        this.setupGoalsForm();
    },

    // Setup personal info form
    setupPersonalInfoForm() {
        const form = document.getElementById('personal-info-form');
        if (!form) return;

        // Load existing data
        this.loadPersonalInfo();

        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.savePersonalInfo();
        });

        // Auto-save on input
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('change', () => {
                this.autoSavePersonalInfo();
            });
        });
    },

    // Setup preferences form
    setupPreferencesForm() {
        const saveBtn = document.getElementById('save-preferences');
        if (!saveBtn) return;

        // Load existing preferences
        this.loadPreferences();

        saveBtn.addEventListener('click', () => {
            this.savePreferences();
        });

        // Setup toggle switches
        this.setupToggleSwitches();
    },

    // Setup toggle switches
    setupToggleSwitches() {
        const toggles = document.querySelectorAll('.toggle-input');
        
        toggles.forEach(toggle => {
            toggle.addEventListener('change', () => {
                this.updateToggleState(toggle);
            });
        });
    },

    // Update toggle switch state
    updateToggleState(toggle) {
        const slider = toggle.nextElementSibling;
        if (slider && slider.classList.contains('toggle-slider')) {
            if (toggle.checked) {
                slider.style.backgroundColor = '#00BFFF';
            } else {
                slider.style.backgroundColor = '#D1D5DB';
            }
        }
    },

    // Setup goals form
    setupGoalsForm() {
        const saveBtn = document.getElementById('save-goals');
        const resetBtn = document.getElementById('reset-goals');
        
        if (!saveBtn) return;

        // Load existing goals
        this.loadGoals();

        saveBtn.addEventListener('click', () => {
            this.saveGoals();
        });

        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetGoals();
            });
        }

        // Setup goal input validation
        this.setupGoalValidation();
    },

    // Setup goal input validation
    setupGoalValidation() {
        const goalInputs = document.querySelectorAll('#goals-tab input[type="number"]');
        
        goalInputs.forEach(input => {
            input.addEventListener('input', () => {
                this.validateGoalInput(input);
                this.updateGoalProgress(input);
            });
        });
    },

    // Validate goal input
    validateGoalInput(input) {
        const value = parseInt(input.value);
        const min = parseInt(input.min);
        const max = parseInt(input.max);
        
        if (isNaN(value) || value < min || value > max) {
            input.style.borderColor = '#EF4444';
        } else {
            input.style.borderColor = '';
        }
    },

    // Update goal progress display
    updateGoalProgress(input) {
        const goalType = input.id.replace('-goal', '');
        const progressBar = document.getElementById(`${goalType}-progress`);
        const progressText = document.getElementById(`${goalType}-progress-text`);
        
        if (!progressBar || !progressText) return;

        // Calculate progress based on current stats
        let progress = 0;
        const goalValue = parseInt(input.value) || 0;
        
        if (window.KhulisoReads) {
            const books = window.KhulisoReads.state.books;
            const completedBooks = books.filter(b => b.status === 'completed').length;
            
            switch (goalType) {
                case 'yearly':
                    progress = goalValue > 0 ? (completedBooks / goalValue) * 100 : 0;
                    break;
                case 'monthly':
                    // Simplified calculation for demo
                    progress = goalValue > 0 ? (completedBooks / goalValue) * 100 : 0;
                    break;
                case 'daily':
                    // Simplified calculation for demo
                    progress = Math.min(100, Math.random() * 100);
                    break;
                case 'streak':
                    const currentStreak = window.KhulisoReads.calculateReadingStreak();
                    progress = goalValue > 0 ? (currentStreak / goalValue) * 100 : 0;
                    break;
            }
        }
        
        progress = Math.min(100, Math.max(0, progress));
        
        progressBar.style.width = `${progress}%`;
        progressText.textContent = `${Math.round(progress)}% complete`;
    },

    // Setup avatar modal
    setupAvatarModal() {
        const avatarEdit = document.getElementById('avatar-edit');
        const avatarModal = document.getElementById('avatar-modal');
        const closeBtn = document.getElementById('avatar-modal-close');
        const emojiOptions = document.querySelectorAll('.emoji-option');

        if (avatarEdit && avatarModal) {
            avatarEdit.addEventListener('click', () => {
                this.showModal(avatarModal);
            });
        }

        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.hideModal(avatarModal);
            });
        }

        emojiOptions.forEach(option => {
            option.addEventListener('click', () => {
                const emoji = option.getAttribute('data-emoji');
                this.updateAvatar(emoji);
                this.hideModal(avatarModal);
            });
        });
    },

    // Setup data management
    setupDataManagement() {
        this.setupDataExport();
        this.setupDataImport();
        this.setupDataClear();
    },

    // Setup data export
    setupDataExport() {
        const exportJsonBtn = document.getElementById('export-json');
        const exportCsvBtn = document.getElementById('export-csv');
        const exportPdfBtn = document.getElementById('export-pdf');

        if (exportJsonBtn) {
            exportJsonBtn.addEventListener('click', () => {
                this.exportData('json');
            });
        }

        if (exportCsvBtn) {
            exportCsvBtn.addEventListener('click', () => {
                this.exportData('csv');
            });
        }

        if (exportPdfBtn) {
            exportPdfBtn.addEventListener('click', () => {
                this.exportData('pdf');
            });
        }
    },

    // Setup data import
    setupDataImport() {
        const importBtn = document.getElementById('import-btn');
        const importFile = document.getElementById('import-file');
        const importFilename = document.getElementById('import-filename');

        if (importBtn && importFile) {
            importBtn.addEventListener('click', () => {
                importFile.click();
            });

            importFile.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    if (importFilename) {
                        importFilename.textContent = file.name;
                    }
                    this.importData(file);
                }
            });
        }
    },

    // Setup data clear
    setupDataClear() {
        const clearBtn = document.getElementById('clear-all-data');
        
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.confirmDataClear();
            });
        }
    },

    // Load profile data
    loadProfileData() {
        this.loadPersonalInfo();
        this.loadPreferences();
        this.loadGoals();
        this.updateProfileStats();
    },

    // Load personal info
    loadPersonalInfo() {
        const savedInfo = this.getSavedPersonalInfo();
        
        if (savedInfo) {
            this.populatePersonalInfoForm(savedInfo);
            this.updateProfileDisplay(savedInfo);
        }
    },

    // Get saved personal info
    getSavedPersonalInfo() {
        try {
            const saved = localStorage.getItem('profilePersonalInfo');
            return saved ? JSON.parse(saved) : null;
        } catch {
            return null;
        }
    },

    // Populate personal info form
    populatePersonalInfoForm(info) {
        const form = document.getElementById('personal-info-form');
        if (!form) return;

        Object.keys(info).forEach(key => {
            const field = form.querySelector(`[name="${key}"]`);
            if (field) {
                field.value = info[key] || '';
            }
        });
    },

    // Update profile display
    updateProfileDisplay(info) {
        const profileName = document.getElementById('profile-name');
        const profileTitle = document.getElementById('profile-title');
        
        if (profileName && (info.firstName || info.lastName)) {
            profileName.textContent = `${info.firstName || ''} ${info.lastName || ''}`.trim() || 'Reader';
        }
        
        if (profileTitle && info.bio) {
            profileTitle.textContent = info.bio.substring(0, 50) + (info.bio.length > 50 ? '...' : '');
        }
    },

    // Load preferences
    loadPreferences() {
        if (!window.KhulisoReads) return;
        
        const preferences = window.KhulisoReads.state.preferences;
        
        // Theme preference
        const themeSelect = document.getElementById('theme-preference');
        if (themeSelect) {
            themeSelect.value = preferences.theme || 'auto';
        }
        
        // Default view
        const defaultViewSelect = document.getElementById('default-view');
        if (defaultViewSelect) {
            defaultViewSelect.value = preferences.defaultView || 'grid';
        }
        
        // Notification preferences
        const readingReminders = document.getElementById('reading-reminders');
        const goalNotifications = document.getElementById('goal-notifications');
        const achievementAlerts = document.getElementById('achievement-alerts');
        
        if (readingReminders) {
            readingReminders.checked = preferences.notifications?.reading ?? true;
            this.updateToggleState(readingReminders);
        }
        
        if (goalNotifications) {
            goalNotifications.checked = preferences.notifications?.goals ?? true;
            this.updateToggleState(goalNotifications);
        }
        
        if (achievementAlerts) {
            achievementAlerts.checked = preferences.notifications?.achievements ?? true;
            this.updateToggleState(achievementAlerts);
        }
        
        // Privacy preferences
        const analyticsTracking = document.getElementById('analytics-tracking');
        const dataBackup = document.getElementById('data-backup');
        
        if (analyticsTracking) {
            analyticsTracking.checked = preferences.privacy?.analytics ?? true;
            this.updateToggleState(analyticsTracking);
        }
        
        if (dataBackup) {
            dataBackup.checked = preferences.privacy?.backup ?? true;
            this.updateToggleState(dataBackup);
        }
    },

    // Load goals
    loadGoals() {
        if (!window.KhulisoReads) return;
        
        const goals = window.KhulisoReads.state.goals;
        
        const yearlyGoal = document.getElementById('yearly-goal');
        const monthlyGoal = document.getElementById('monthly-goal');
        const dailyGoal = document.getElementById('daily-goal');
        const streakGoal = document.getElementById('streak-goal');
        
        if (yearlyGoal) {
            yearlyGoal.value = goals.yearly || 20;
            this.updateGoalProgress(yearlyGoal);
        }
        
        if (monthlyGoal) {
            monthlyGoal.value = goals.monthly || 2;
            this.updateGoalProgress(monthlyGoal);
        }
        
        if (dailyGoal) {
            dailyGoal.value = goals.daily || 30;
            this.updateGoalProgress(dailyGoal);
        }
        
        if (streakGoal) {
            streakGoal.value = goals.streak || 7;
            this.updateGoalProgress(streakGoal);
        }
    },

    // Save personal info
    savePersonalInfo() {
        const form = document.getElementById('personal-info-form');
        if (!form) return;

        const formData = new FormData(form);
        const info = {};
        
        for (let [key, value] of formData.entries()) {
            info[key] = value;
        }

        try {
            localStorage.setItem('profilePersonalInfo', JSON.stringify(info));
            this.updateProfileDisplay(info);
            window.KhulisoReads?.showNotification('Personal information saved!', 'success');
        } catch (error) {
            window.KhulisoReads?.showNotification('Error saving personal information', 'error');
        }
    },

    // Auto-save personal info
    autoSavePersonalInfo() {
        // Debounced auto-save
        clearTimeout(this.autoSaveTimeout);
        this.autoSaveTimeout = setTimeout(() => {
            this.savePersonalInfo();
        }, 2000);
    },

    // Save preferences
    savePreferences() {
        if (!window.KhulisoReads) return;

        const themePreference = document.getElementById('theme-preference')?.value;
        const defaultView = document.getElementById('default-view')?.value;
        const readingReminders = document.getElementById('reading-reminders')?.checked;
        const goalNotifications = document.getElementById('goal-notifications')?.checked;
        const achievementAlerts = document.getElementById('achievement-alerts')?.checked;
        const analyticsTracking = document.getElementById('analytics-tracking')?.checked;
        const dataBackup = document.getElementById('data-backup')?.checked;

        // Update preferences
        if (themePreference) window.KhulisoReads.state.preferences.theme = themePreference;
        if (defaultView) window.KhulisoReads.state.preferences.defaultView = defaultView;
        
        window.KhulisoReads.state.preferences.notifications = {
            reading: readingReminders ?? true,
            goals: goalNotifications ?? true,
            achievements: achievementAlerts ?? true
        };
        
        window.KhulisoReads.state.preferences.privacy = {
            analytics: analyticsTracking ?? true,
            backup: dataBackup ?? true
        };

        window.KhulisoReads.saveToStorage();
        
        // Apply theme change
        if (themePreference) {
            window.KhulisoReads.initializeTheme();
        }
        
        window.KhulisoReads.showNotification('Preferences saved!', 'success');
    },

    // Save goals
    saveGoals() {
        if (!window.KhulisoReads) return;

        const yearlyGoal = document.getElementById('yearly-goal')?.value;
        const monthlyGoal = document.getElementById('monthly-goal')?.value;
        const dailyGoal = document.getElementById('daily-goal')?.value;
        const streakGoal = document.getElementById('streak-goal')?.value;

        if (yearlyGoal) window.KhulisoReads.state.goals.yearly = parseInt(yearlyGoal);
        if (monthlyGoal) window.KhulisoReads.state.goals.monthly = parseInt(monthlyGoal);
        if (dailyGoal) window.KhulisoReads.state.goals.daily = parseInt(dailyGoal);
        if (streakGoal) window.KhulisoReads.state.goals.streak = parseInt(streakGoal);

        window.KhulisoReads.saveToStorage();
        window.KhulisoReads.updateStats();
        
        window.KhulisoReads.showNotification('Reading goals updated!', 'success');
    },

    // Reset goals to default
    resetGoals() {
        const confirmed = confirm('Are you sure you want to reset all goals to default values?');
        if (!confirmed) return;

        if (window.KhulisoReads) {
            window.KhulisoReads.state.goals = {
                yearly: 20,
                monthly: 2,
                daily: 30,
                streak: 7
            };
            
            window.KhulisoReads.saveToStorage();
            this.loadGoals();
            window.KhulisoReads.showNotification('Goals reset to default values', 'info');
        }
    },

    // Update avatar
    updateAvatar(emoji) {
        const avatarDisplay = document.getElementById('avatar-display');
        if (avatarDisplay) {
            avatarDisplay.textContent = emoji;
            
            // Save avatar preference
            try {
                localStorage.setItem('profileAvatar', emoji);
                window.KhulisoReads?.showNotification('Avatar updated!', 'success');
            } catch (error) {
                console.error('Error saving avatar:', error);
            }
        }
    },

    // Load achievements
    loadAchievements() {
        const achievementsGrid = document.getElementById('achievements-grid');
        if (!achievementsGrid) return;

        this.achievements = this.calculateAchievements();
        achievementsGrid.innerHTML = '';

        this.achievements.forEach(achievement => {
            const achievementCard = this.createAchievementCard(achievement);
            achievementsGrid.appendChild(achievementCard);
        });
    },

    // Calculate achievements
    calculateAchievements() {
        const books = window.KhulisoReads?.state?.books || [];
        const completedBooks = books.filter(book => book.status === 'completed');
        const currentStreak = window.KhulisoReads?.calculateReadingStreak() || 0;
        const ratedBooks = books.filter(book => book.rating > 0);
        const genres = [...new Set(books.map(book => book.genre))];

        return [
            {
                id: 1,
                icon: '📚',
                title: 'First Book',
                description: 'Complete your first book',
                unlocked: completedBooks.length >= 1,
                progress: Math.min(completedBooks.length, 1),
                target: 1
            },
            {
                id: 2,
                icon: '🔥',
                title: 'Week Streak',
                description: 'Read for 7 consecutive days',
                unlocked: currentStreak >= 7,
                progress: Math.min(currentStreak, 7),
                target: 7
            },
            {
                id: 3,
                icon: '📖',
                title: 'Bookworm',
                description: 'Read 10 books',
                unlocked: completedBooks.length >= 10,
                progress: Math.min(completedBooks.length, 10),
                target: 10
            },
            {
                id: 4,
                icon: '🎯',
                title: 'Goal Achiever',
                description: 'Reach your yearly reading goal',
                unlocked: completedBooks.length >= (window.KhulisoReads?.state?.goals?.yearly || 20),
                progress: completedBooks.length,
                target: window.KhulisoReads?.state?.goals?.yearly || 20
            },
            {
                id: 5,
                icon: '⭐',
                title: 'Reviewer',
                description: 'Rate 5 books',
                unlocked: ratedBooks.length >= 5,
                progress: Math.min(ratedBooks.length, 5),
                target: 5
            },
            {
                id: 6,
                icon: '🌟',
                title: 'Diverse Reader',
                description: 'Read books from 5 different genres',
                unlocked: genres.length >= 5,
                progress: Math.min(genres.length, 5),
                target: 5
            },
            {
                id: 7,
                icon: '🏆',
                title: 'Marathon Reader',
                description: 'Read 50 books',
                unlocked: completedBooks.length >= 50,
                progress: Math.min(completedBooks.length, 50),
                target: 50
            },
            {
                id: 8,
                icon: '💎',
                title: 'Perfectionist',
                description: 'Rate 10 books with 5 stars',
                unlocked: books.filter(book => book.rating === 5).length >= 10,
                progress: Math.min(books.filter(book => book.rating === 5).length, 10),
                target: 10
            }
        ];
    },

    // Create achievement card
    createAchievementCard(achievement) {
        const card = document.createElement('div');
        card.className = `achievement-card ${achievement.unlocked ? 'unlocked' : ''}`;
        
        const progressPercent = (achievement.progress / achievement.target) * 100;
        
        card.innerHTML = `
            <div class="achievement-icon">${achievement.icon}</div>
            <h4>${achievement.title}</h4>
            <p>${achievement.description}</p>
            <div class="achievement-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progressPercent}%"></div>
                </div>
                <span class="progress-text">${achievement.progress}/${achievement.target}</span>
            </div>
            ${achievement.unlocked ? '<div class="achievement-badge">Unlocked!</div>' : ''}
        `;
        
        return card;
    },

    // Update profile stats
    updateProfileStats() {
        if (!window.KhulisoReads) return;

        const books = window.KhulisoReads.state.books;
        const completedBooks = books.filter(book => book.status === 'completed').length;
        const totalReadingTime = window.KhulisoReads.state.readingSessions.reduce((total, session) => total + session.minutes, 0);
        const readingStreak = window.KhulisoReads.calculateReadingStreak();

        this.updateElement('profile-books-read', completedBooks);
        this.updateElement('profile-reading-time', Math.round(totalReadingTime / 60));
        this.updateElement('profile-streak', readingStreak);
    },

    // Export data
    exportData(format) {
        if (!window.KhulisoReads) return;

        const data = {
            books: window.KhulisoReads.state.books,
            readingSessions: window.KhulisoReads.state.readingSessions,
            goals: window.KhulisoReads.state.goals,
            preferences: window.KhulisoReads.state.preferences,
            personalInfo: this.getSavedPersonalInfo(),
            achievements: this.achievements,
            exportDate: new Date().toISOString()
        };

        let content, filename, mimeType;

        switch (format) {
            case 'json':
                content = JSON.stringify(data, null, 2);
                filename = `khulisoreads-data-${new Date().toISOString().split('T')[0]}.json`;
                mimeType = 'application/json';
                break;
            case 'csv':
                content = this.convertToCSV(data.books);
                filename = `khulisoreads-books-${new Date().toISOString().split('T')[0]}.csv`;
                mimeType = 'text/csv';
                break;
            case 'pdf':
                window.KhulisoReads.showNotification('PDF export feature coming soon!', 'info');
                return;
        }

        this.downloadFile(content, filename, mimeType);
        window.KhulisoReads.showNotification(`Data exported as ${format.toUpperCase()}!`, 'success');
    },

    // Convert books to CSV
    convertToCSV(books) {
        const headers = ['Title', 'Author', 'Genre', 'Pages', 'Current Page', 'Status', 'Date Added', 'Date Completed', 'Rating'];
        const rows = books.map(book => [
            book.title,
            book.author,
            book.genre,
            book.pages,
            book.currentPage,
            book.status,
            new Date(book.dateAdded).toLocaleDateString(),
            book.dateCompleted ? new Date(book.dateCompleted).toLocaleDateString() : '',
            book.rating
        ]);

        return [headers, ...rows].map(row => 
            row.map(field => `"${field}"`).join(',')
        ).join('\n');
    },

    // Download file
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    },

    // Import data
    importData(file) {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            try {
                const content = e.target.result;
                let data;
                
                if (file.type === 'application/json' || file.name.endsWith('.json')) {
                    data = JSON.parse(content);
                    this.processImportedData(data);
                } else if (file.type === 'text/csv' || file.name.endsWith('.csv')) {
                    window.KhulisoReads?.showNotification('CSV import feature coming soon!', 'info');
                } else {
                    window.KhulisoReads?.showNotification('Unsupported file format', 'error');
                }
            } catch (error) {
                window.KhulisoReads?.showNotification('Error importing data: Invalid file format', 'error');
            }
        };
        
        reader.readAsText(file);
    },

    // Process imported data
    processImportedData(data) {
        const confirmed = confirm('This will replace your current data. Are you sure you want to continue?');
        if (!confirmed) return;

        if (window.KhulisoReads && data.books) {
            window.KhulisoReads.state.books = data.books;
            if (data.readingSessions) window.KhulisoReads.state.readingSessions = data.readingSessions;
            if (data.goals) window.KhulisoReads.state.goals = data.goals;
            if (data.preferences) window.KhulisoReads.state.preferences = data.preferences;
            
            window.KhulisoReads.saveToStorage();
            window.KhulisoReads.updateStats();
            
            // Reload profile data
            this.loadProfileData();
            
            window.KhulisoReads.showNotification('Data imported successfully!', 'success');
        }
    },

    // Confirm data clear
    confirmDataClear() {
        const confirmed = confirm('Are you sure you want to delete ALL your data? This action cannot be undone.');
        if (!confirmed) return;

        const doubleConfirmed = confirm('This will permanently delete all your books, reading sessions, goals, and preferences. Type "DELETE" to confirm.');
        if (!doubleConfirmed) return;

        this.clearAllData();
    },

    // Clear all data
    clearAllData() {
        try {
            // Clear localStorage
            localStorage.removeItem('khulisoReadsState');
            localStorage.removeItem('profilePersonalInfo');
            localStorage.removeItem('profileAvatar');
            localStorage.removeItem('contactFormData');
            
            // Reset app state
            if (window.KhulisoReads) {
                window.KhulisoReads.state = {
                    currentTheme: 'light',
                    currentUser: null,
                    books: [],
                    readingSessions: [],
                    goals: {
                        yearly: 20,
                        monthly: 2,
                        daily: 30,
                        streak: 7
                    },
                    preferences: {
                        theme: 'auto',
                        defaultView: 'grid',
                        notifications: {
                            reading: true,
                            goals: true,
                            achievements: true
                        },
                        privacy: {
                            analytics: true,
                            backup: true
                        }
                    }
                };
                
                window.KhulisoReads.saveToStorage();
                window.KhulisoReads.updateStats();
            }
            
            // Reload page to reset everything
            setTimeout(() => {
                window.location.reload();
            }, 1000);
            
            window.KhulisoReads?.showNotification('All data cleared successfully', 'success');
        } catch (error) {
            window.KhulisoReads?.showNotification('Error clearing data', 'error');
        }
    },

    // Update storage info
    updateStorageInfo() {
        const booksCount = document.getElementById('books-count');
        const sessionsCount = document.getElementById('sessions-count');
        const storageUsed = document.getElementById('storage-used');
        
        if (window.KhulisoReads) {
            const books = window.KhulisoReads.state.books.length;
            const sessions = window.KhulisoReads.state.readingSessions.length;
            
            if (booksCount) booksCount.textContent = books;
            if (sessionsCount) sessionsCount.textContent = sessions;
            
            // Calculate storage usage
            try {
                const dataSize = JSON.stringify(window.KhulisoReads.state).length;
                const sizeKB = Math.round(dataSize / 1024 * 100) / 100;
                if (storageUsed) storageUsed.textContent = `${sizeKB} KB`;
            } catch {
                if (storageUsed) storageUsed.textContent = 'Unknown';
            }
        }
    },

    // Utility functions
    updateElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    },

    showModal(modal) {
        if (modal) {
            modal.classList.add('active');
            document.body.classList.add('no-scroll');
        }
    },

    hideModal(modal) {
        if (modal) {
            modal.classList.remove('active');
            document.body.classList.remove('no-scroll');
        }
    }
};

// Initialize profile page when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait for main app to initialize
    setTimeout(() => {
        Profile.init();
    }, 100);
});

// Export for global access
window.Profile = Profile;

